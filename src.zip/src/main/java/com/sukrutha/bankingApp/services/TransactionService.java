//package com.sukrutha.bankingApp.services;
//
//import java.util.List;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import com.sukrutha.bankingApp.Repositories.TransactionRepository;
//import com.sukrutha.bankingApp.entities.Transaction;
//
//@Service
//public class TransactionService {
//	
//	
//	@Autowired
//    TransactionRepository transactionRepo;
//	
//	
//	@Autowired
//	AccountService accountService;
//	
//	public List<Transaction> findAllTransactionsByAccountNumber(String accountNumber){
//		return null;
//		
//	}
//	
//	public boolean sendMoney(String accountNumber, String beneficiaryAccountNumber,double amount) {
//		return false;
//		
//	}
//	
//	
//
//}
