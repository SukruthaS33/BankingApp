package com.sukrutha.bankingApp.customExceptions;

public class InputException extends RuntimeException {

	
	public InputException(String str) {
		super(str);
	}
}
